// status can be "online", "idle", "dnd", or "invisible" or "offline"
export default [
    {
        channelId: "1476682245992616146",
        serverId: "1144621742174781480",
        token: process.env.token1,
        selfDeaf: false,
        autoReconnect: {
            enabled: true,
            delay: 5, // ثواني
            maxRetries: 5,
        },
        presence: {
            status: "dnd",
        },
        selfMute: true,
    },
];